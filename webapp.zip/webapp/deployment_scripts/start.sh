#!/usr/bin/env bash

sudo systemctl start webapp