#!/usr/bin/env bash

sudo systemctl stop webapp
